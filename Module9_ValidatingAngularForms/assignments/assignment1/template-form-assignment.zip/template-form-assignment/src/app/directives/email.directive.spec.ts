import { EmailDirective } from './email.directive';

describe('EmailDirective', () => {
  it('should create an instance', () => {
    const directive = new EmailDirective();
    expect(directive).toBeTruthy();
  });
});
