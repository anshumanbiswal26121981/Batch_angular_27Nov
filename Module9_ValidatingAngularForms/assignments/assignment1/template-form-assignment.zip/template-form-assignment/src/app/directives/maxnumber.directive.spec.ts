import { MaxnumberDirective } from './maxnumber.directive';

describe('MaxnumberDirective', () => {
  it('should create an instance', () => {
    const directive = new MaxnumberDirective();
    expect(directive).toBeTruthy();
  });
});
