import { MinnumberDirective } from './minnumber.directive';

describe('MinnumberDirective', () => {
  it('should create an instance', () => {
    const directive = new MinnumberDirective();
    expect(directive).toBeTruthy();
  });
});
