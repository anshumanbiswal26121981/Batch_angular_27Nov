export class Friend {
    id: string | undefined;
    userId: string | undefined;
    friendId: string | undefined;
    status: string | undefined;
}