export class Register {
    firstName: string | undefined;
    lastName: string | undefined;
    dob: Date | undefined;
    email: string | undefined;
    password: string | undefined;
    gender: string | undefined;
    isActive: boolean | undefined;
}