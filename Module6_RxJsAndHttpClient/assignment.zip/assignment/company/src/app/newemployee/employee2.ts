export interface NewEmployee {

    id : String,
 
    employee_name : String,
 
    employee_salary : Number,
 
    employee_age: Number,
 
    profile_image: String
 
 }