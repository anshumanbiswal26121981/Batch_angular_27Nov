export interface Employee {

    employeeId : number,
 
    firstName : string,
 
    lastName : string,
 
    salary:number,
 
    dob:Date,  
 
    email :string,

    action: string
 
 }